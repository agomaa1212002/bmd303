import 'package:flutter/material.dart';

const cardBackgroundColor = Color(0xFFFFFFFF);
const primaryColor = Color(0xFF2697FF);
const secondaryColor = Color(0xFFFFFFFF);
const backgroundColor = Color(0xFFFFFFFF);
const selectionColor = Color(0xFF88B2AC);

const defaultPadding = 20.0;
