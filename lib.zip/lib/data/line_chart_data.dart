import 'package:fl_chart/fl_chart.dart';

class LineData {



  final leftTitle = {
    0: '70',
    20: '50',
    40: '60',
    60: '40',
    80: '80',
    100: '100'
  };
  final bottomTitle = {
    0: 'Jan',
    10: 'Feb',
    20: 'Mar',
    30: 'Apr',
    40: 'May',
    50: 'Jun',
    60: 'Jul',
    70: 'Aug',
    80: 'Sep',
    90: 'Oct',
    100: 'Nov',
    110: 'Dec',
  };
}
