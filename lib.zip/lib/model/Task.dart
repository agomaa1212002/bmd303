// import 'package:get_storage/get_storage.dart';
//
// class Task{
//   int? id;
//   String?  title;
//   String? note;
//   int ?isCompleted;
//   String? date;
//   String ?startTime;
//   String? endTime;
//   int? color;
//
//
//
//
// Task({
//   this.id,
//   this.note,
// this.title,
//  this.isCompleted,
//  this.date,
// this.startTime,
// this.endTime,
//  this.color,
//
//
// });
// Task.fromjson(Map<String,dynamic> json){
//
//     id = json['id'];
//     title  = json['title'];
//     note = json['note'];
//     date =json['date'];
//    isCompleted  = json[' isCompleted'];
//    date  = json[' date'];
//   startTime  = json[' startTime'];
//    endTime  = json['endTime'];
//    color  = json['color'];
//
//
//
// }
// Map<String,dynamic>toJson(){
//   final Map<String,dynamic>Data = new Map<String,dynamic>();
//    Data['id']=this.id;
//   Data['note']=this.note;
//   Data['title']= this.title;
//   Data['date']= this.date;
//   Data['isCompleted']=this.isCompleted;
//   Data['date']=this.date;
//   Data['startTime']=this.startTime;
//   Data['endTime']= this.endTime;
//   Data['color']=this.color;
//
//
//   return Data;
//
// }
// }