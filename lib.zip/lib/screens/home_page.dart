// import 'package:date_picker_timeline/date_picker_timeline.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:intl/intl.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:intl/intl.dart';
// import 'package:neutrition_sqlite/controllers/Task_controller.dart';
// import 'package:neutrition_sqlite/screens/app.dart';
// import 'package:neutrition_sqlite/screens/theme.dart';
//
//
// import '../servises/theme_servises.dart';
// import '../widgets/add_task_bar.dart';
// import '../widgets/botton.dart';
//
// class HomePage extends StatefulWidget {
//   const HomePage({ super.key });
//
//   @override
//   _HomePageState  createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//  DateTime _selectedDate =DateTime.now();
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: _appBar(),
//       //add date bar
//       body: Column(
//         children: [
//           _addtaskBar(),
//           Container(
//             margin: const EdgeInsets.only(top: 20,left: 20),
//             child: DatePicker(
//                 DateTime.now(),
//                 height:100 ,
//                 width: 80,
//                 initialSelectedDate: DateTime.now() ,
//                 selectionColor:primaryClr ,
//                 selectedTextColor: Colors.white,
//                 dateTextStyle:GoogleFonts.lato(
//                     textStyle:TextStyle(
//                         fontSize: 20,
//                         fontWeight: FontWeight.w600,
//                         color:Colors.grey
//
//                     )
//                 ),
//                 dayTextStyle:GoogleFonts.lato(
//                     textStyle:TextStyle(
//                         fontSize: 16,
//                         fontWeight: FontWeight.w600,
//                         color:Colors.grey
//
//                     )
//                 ),
//                 monthTextStyle:GoogleFonts.lato(
//                     textStyle:TextStyle(
//                         fontSize: 10,
//                         fontWeight: FontWeight.w600,
//                         color:Colors.grey
//
//
//                     )
//                 ),
//                 onDateChange: (date){
//                   _selectedDate=date;
//
//
//
//                 }
//             ),
//           ),
//
//           // _showTask(),
//         ],
//
//       )
//
//     );
//
//   }
//  // _showTask(){
//  //   return Expanded(
//  //     child:Obx((){
//  //       return ListView.builder(
//  //
//  //           itemBuilder: (_ ,context){
//  //             return Container(
//  //               width: 100,
//  //               height: 50,
//  //               color: Colors.green,
//  //             ) ;
//  //           });
//  //     }),
//  //
//  //   );
//  // }
// }
//
// _addtaskBar() {
//   return Container(
//     margin: const EdgeInsets.only(left: 20, right: 20, top: 10),
//     child: Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Container(
//           margin: const EdgeInsets.symmetric(horizontal: 20),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 DateFormat.yMMMMd().format(DateTime.now()),
//                 style: subHeadingStyle,
//               ),
//               Text(
//                 "Today",
//                 style: headingStyle,
//               ),
//             ],
//           ),
//         ),
//         GestureDetector(
//           onTap: () {
//             // Navigate to the AddTaskPage using GetX
//             Get.to(() => AddTaskPaged);
//           },
//           child: Mybutton(
//             label: "Appointment", onTap: () {   Get.to(() => AddTaskPaged); },
//           ),
//         ),
//       ],
//     ),
//   );
// }
// _appBar() {
//   return AppBar(
//     leading: GestureDetector(
//       onTap: () {
//         themeservise().swiththeme();
//       },
//       child: Icon(
//         Icons.nightlight_round,
//         size: 20,
//       ),
//     ),
//     actions: [
//       GestureDetector(
//         onTap: () {
//           // Handle the onTap event for the person icon
//           // For example, navigate to profile page
//         },
//         child: Icon(
//           Icons.person,
//           size: 20,
//         ),
//       ),
//       SizedBox(width: 20),
//     ],
//   );
// }
//
import 'package:date_picker_timeline/date_picker_timeline.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:neutrition_sqlite/screens/theme.dart';
import 'package:neutrition_sqlite/servises/theme_servises.dart';
import '../widgets/add_task_bar.dart';
import '../widgets/botton.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'app.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
Stream<List<Map<String, dynamic>>> _fetchAppointments(DateTime selectedDate) {
  return FirebaseFirestore.instance.collection('patients').snapshots().map(
        (snapshot) {
      List<Map<String, dynamic>> appointments = [];
      for (var patientDoc in snapshot.docs) {
        var patientData = patientDoc.data() as Map<String, dynamic>;
        var appointmentsSnapshot =
        patientDoc.reference
            .collection('appointments')
            .where('date', isEqualTo: DateFormat.yMd().format(selectedDate))
            .snapshots();
        appointmentsSnapshot.listen((appointmentsSnapshot) {
          for (var appointmentDoc in appointmentsSnapshot.docs) {
            var appointmentData = appointmentDoc.data() as Map<String, dynamic>;
            appointments.add(appointmentData);
          }
        });
      }
      return appointments;
    },
  );
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DateTime _selecteDate = DateTime.now();
  late Stream<List<Map<String, dynamic>>> _appointmentsStream;

  @override
  void initState() {
    super.initState();
    _appointmentsStream = _fetchAppointments();
  }

  Stream<List<Map<String, dynamic>>> _fetchAppointments() {
    return FirebaseFirestore.instance.collection('patients').snapshots().map(
          (snapshot) {
        List<Map<String, dynamic>> appointments = [];
        for (var patientDoc in snapshot.docs) {
          var patientData = patientDoc.data() as Map<String, dynamic>;
          var appointmentsSnapshot =
          patientDoc.reference.collection('appointments').snapshots();
          appointmentsSnapshot.listen((appointmentsSnapshot) {
            for (var appointmentDoc in appointmentsSnapshot.docs) {
              var appointmentData =
              appointmentDoc.data() as Map<String, dynamic>;
              if (DateFormat.yMd().format(appointmentData['date'].toDate()) ==
                  DateFormat.yMd().format(_selecteDate)) {
                appointments.add(appointmentData);
              }
            }
          });
        }
        return appointments;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar() ,
      body: Column(
        children: [
          _addTaskBar(),
          _datePicker(),
          Expanded(child: _appointmentsList()),
        ],
      ),
    );
  }

  Widget _datePicker() {
    return Container(
      margin: const EdgeInsets.only(top: 20, left: 20),
      child: DatePicker(
        DateTime.now(),
        height: 100,
        width: 80,
        initialSelectedDate: DateTime.now(),
        selectionColor: Colors.blue,
        selectedTextColor: Colors.white,
        dateTextStyle: GoogleFonts.lato(
          textStyle: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Colors.grey,
          ),
        ),
        dayTextStyle: GoogleFonts.lato(
          textStyle: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: Colors.grey,
          ),
        ),
        monthTextStyle: GoogleFonts.lato(
          textStyle: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: Colors.grey,
          ),
        ),
        onDateChange: (date) {
          setState(() {
           _selecteDate = date;
          });
        },
      ),
    );
  }

  Widget _appointmentsList() {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _appointmentsStream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text('No appointments found'));
        } else {
          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              var appointment = snapshot.data![index];
              return _appointmentCard(appointment);
            },
          );
        }
      },
    );
  }

  Widget _appointmentCard(Map<String, dynamic> appointment) {
    return Card(
      margin: EdgeInsets.all(10),
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.all(15),
        leading: Icon(Icons.event, color: Colors.blue, size: 40),
        title: Text(
          appointment['title'] ?? 'No Title',
          style: GoogleFonts.lato(
            textStyle: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 5),
            Text(
              appointment['note'] ?? 'No Description',
              style: GoogleFonts.lato(
                textStyle: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(height: 5),
            Text(
              'Time: ${appointment['startTime']} - ${appointment['endTime']}',
              style: GoogleFonts.lato(
                textStyle: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _addTaskBar() {
    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20, top: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat.yMMMMd().format(DateTime.now()),
                  style: subHeadingStyle,
                ),
                Text(
                  "Today",
                  style: headingStyle,
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: () {
              Get.to(() => AddTaskPaged());
            },
            child: Mybutton(
              label: "Appointment",
              onTap: () {
                Get.to(() => AddTaskPaged());
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _appBar() {
    return AppBar(
      leading: GestureDetector(
        onTap: () {
          themeservise().swiththeme();
        },
        child: Icon(
          Icons.nightlight_round,
          size: 20,
        ),
      ),
      actions: [
        GestureDetector(
          onTap: () {
            // Handle the onTap event for the person icon
            // For example, navigate to profile page
          },
          child: Icon(
            Icons.person,
            size: 20,
          ),
        ),
        SizedBox(width: 20),
      ],
    );
  }
}