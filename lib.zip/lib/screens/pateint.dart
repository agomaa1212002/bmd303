import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import 'main_screen.dart';

class PatientListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Patient List'),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('patients').snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          final patients = snapshot.data!.docs;

          return ListView.builder(
            itemCount: patients.length,
            itemBuilder: (context, index) {
              var patientData = patients[index].data() as Map<String, dynamic>;
              return ListTile(
                leading: CircleAvatar(
                  backgroundImage: AssetImage('assets/images/profile_placeholder.png'), // Use appropriate image here
                ),
                title: Text(patientData['username'] ?? ''),
                subtitle: Text(patientData['email'] ?? ''),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [

                    IconButton(
                      icon: Icon(Icons.delete,color: Colors.red,),
                      onPressed: () {
                        // Show delete confirmation dialog
                        _showDeleteConfirmationDialog(context, patientData);
                      },
                    ),
                  ],
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PatientDetailsScreen(patientData, generatedId: '',),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }

  void _showDeleteConfirmationDialog(BuildContext context, Map<String, dynamic> patientData) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Delete Patient'),
          content: Text('Are you sure you want to delete this patient?'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog
              },
              child: Text('Cancel', style: TextStyle(color: Colors.white)),
              style: TextButton.styleFrom(backgroundColor: Colors.blue),
            ),
            TextButton(
              onPressed: () {
                // Perform delete operation
                _deletePatient(patientData);
                Navigator.pop(context); // Close the dialog
              },
              child: Text('Confirm', style: TextStyle(color: Colors.white)),
              style: TextButton.styleFrom(backgroundColor: Colors.red),
            ),
          ],
        );
      },
    );
  }

  void _deletePatient(Map<String, dynamic> patientData) {
    // Implement deletion logic here

    FirebaseFirestore.instance.collection('patients').doc(patientData['id']).delete();
  }
}





class PatientDetailsScreen extends StatelessWidget {
  final String generatedId;

  PatientDetailsScreen(Map<String, dynamic> patientData, {required this.generatedId});

  @override
  Widget build(BuildContext context) {
    assert(generatedId.isNotEmpty, 'Generated ID must not be empty');

    return Scaffold(
      appBar: AppBar(
        title: Text('Patient Details'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            if (generatedId.isNotEmpty) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => BMICalculatorHistoryScreen(generatedId: generatedId),
                ),
              );
            } else {
              // Handle empty generatedId scenario
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Generated ID is empty!')),
              );
            }
          },
          child: Text('View BMI Calculator History'),
        ),
      ),
    );
  }
}

class BMICalculatorHistoryScreen extends StatelessWidget {
  final String generatedId;

  BMICalculatorHistoryScreen({required this.generatedId});

  @override
  Widget build(BuildContext context) {
    assert(generatedId.isNotEmpty, 'Generated ID must not be empty');

    return Scaffold(
      appBar: AppBar(
        title: Text('BMI Calculator History'),
      ),
      body: FutureBuilder<QuerySnapshot>(
        future: FirebaseFirestore.instance
            .collection('patients')
            .doc(generatedId)
            .collection('BMI Calculator History')
            .get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No data available'));
          }

          final bmiData = snapshot.data!.docs.map((doc) {
            final data = doc.data() as Map<String, dynamic>;
            return BMIData(
              bmi: data['bmi']?.toDouble() ?? 0.0,
              weight: data['weight']?.toDouble() ?? 0.0,
            );
          }).toList();

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: LineChart(
              LineChartData(
                lineBarsData: [
                  LineChartBarData(
                    spots: bmiData
                        .map((data) => FlSpot(data.weight, data.bmi))
                        .toList(),
                    isCurved: true,
                    barWidth: 2,
                    ;color: Colors.blue,
                  ),
                ],
                titlesData: FlTitlesData(
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 22,
                      getTitlesWidget: (value, meta) {
                        return Text(value.toString());
                      },
                    ),
                  ),
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 28,
                      getTitlesWidget: (value, meta) {
                        return Text(value.toString());
                      },
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class BMIData {
  final double bmi;
  final double weight;

  BMIData({required this.bmi, required this.weight});
}
